﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Nojo
{
    public partial class _Default : Page
    {
        
     



        protected void Page_Load(object sender, EventArgs e)
        {

            //On page Load it sets the data source for the repeater to populate based on the product list
            // we use a repepater so that we dont have so much repetition in html and allows us to simulate a db sending its data 
            if (!IsPostBack)
            {
                // Retrieve products from the database
                List<Product> vegetables = GetProductsFromDatabase();

                // Bind the products to the Repeater control
                productRepeater.DataSource = vegetables;
                productRepeater.DataBind();
            }


        }

        private List<Product> GetProductsFromDatabase()
        {
            List<Product> products = new List<Product>();
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\NojoDB.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "GetAllProducts"; // Use the stored procedure name

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure; // Set the command type to stored procedure

                    con.Open();

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Product product = new Product
                        {
                            Name = reader["Name"].ToString(),
                            Price = Convert.ToDouble(reader["Price"]),
                            Cat = reader["CategoryName"].ToString(),
                            imageUrl = reader["PhotoUrl"].ToString(),
                            Qty = 0
                        };

                        products.Add(product);
                    }

                    reader.Close();
                    con.Close();
                }
            }

            return products;
        }

        protected void AddToBasketClick(object sender, EventArgs e)
        {
            //checks if the user is logged in and directs them to the login page if they are not. You only have a cart if you log in
            if (Session["UserLoggedIn"] != null)
            {
                Button addButton = (Button)sender;
                // Get the corresponding card
                RepeaterItem item = (RepeaterItem)addButton.NamingContainer;
                int itemIndex = item.ItemIndex;

                //Get the qty number that users input to pass forward into the session cart
                TextBox quantNumTextBox = (TextBox)item.FindControl("quantNum");


                
                int quantity = 0;
                if (int.TryParse(quantNumTextBox.Text, out int parsedQuantity) && parsedQuantity >= 1)
                {
                    quantity = parsedQuantity;




                    // Retrieve the existing cart from the session or make one if none exist
                    List<Product> cart = Session["Cart"] as List<Product>;
                    if (cart == null)
                    {
                        cart = new List<Product>();
                    }

                    // create a new product with the user's quantity input and get the rest of the values from the actual item from the list that shares its index
                    Product newProd = new Product();
                    newProd.Name = GetProductsFromDatabase()[itemIndex].Name;
                    newProd.Cat = GetProductsFromDatabase()[itemIndex].Cat;
                    newProd.Price = GetProductsFromDatabase()[itemIndex].Price * quantity;
                    newProd.imageUrl = GetProductsFromDatabase()[itemIndex].imageUrl;
                    newProd.Qty = quantity;

                    cart.Add(newProd);


                    Session["Cart"] = cart;
                }
                else
                {
                    quantNumTextBox.Style["border"] = " 3px solid #d42a47";
                }
            }
            else
            {
                Response.Redirect("~/Pages/Login");
                
            }
            }

        protected void ViewMore_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Pages/ShopVegetables");
        }
    }
}

