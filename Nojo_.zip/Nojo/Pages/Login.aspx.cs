﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Nojo
{
    public partial class Login : System.Web.UI.Page
    {
        private readonly string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\NojoDB.mdf;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        //Login 
        protected void LoginClick(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
               
                string username = userField.Text;
                string password = passField.Text;

                string result = string.Empty;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand("CheckUserCredentials", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        // Input parameters
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@Password", password);

                        // Output parameter
                        SqlParameter outputParameter = new SqlParameter("@Result", SqlDbType.VarChar, 50);
                        outputParameter.Direction = ParameterDirection.Output;
                        command.Parameters.Add(outputParameter);

                        try
                        {
                            connection.Open();
                            command.ExecuteNonQuery();

                            // Retrieve the result from the output parameter
                            result = outputParameter.Value.ToString();
                        }
                        catch (Exception ex)
                        {
                            // Handle database error
                            // Log or display the error message
                            // e.g., errorMessageLabel.Text = ex.Message;
                        }
                    }
                }

                if (result == "Customer")
                {
                    // Customer login successful
                    List<Product> cart = new List<Product>();
                    Session["UserName"] = username;
                    Session["UserLoggedIn"] = true;
                    Session["Cart"] = cart;
                    Response.Redirect("~/Pages/Default");
                }
                else if (result == "Admin")
                {
                    // Admin login successful
                    Session["AdminUserName"] = username;
                    Session["AdminPassword"] = passField.Text;
                    Response.Redirect("~/Pages/AdminPanel");
                }
                else
                {
                   
                }
            }
        }


        protected void ValidateLogin(object source, ServerValidateEventArgs args)
        {
            
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("ValidateUserLogin", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure; // Set the command type to stored procedure

                    cmd.Parameters.AddWithValue("@Username", userField.Text);
                    cmd.Parameters.AddWithValue("@Password", passField.Text);
                    SqlParameter isValidParam = new SqlParameter("@IsValid", SqlDbType.Bit);
                    isValidParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(isValidParam);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    args.IsValid = (bool)isValidParam.Value;
                }
            }
        }







        //Register
        protected void UsernameValidation(object source, ServerValidateEventArgs args)
        {
            string username = regUser.Text;

            // Use the stored procedure for username validation
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("CheckUsernameAvailability", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure; // Set the command type to stored procedure

                    cmd.Parameters.AddWithValue("@UserName", username);
                    SqlParameter isAvailableParam = new SqlParameter("@IsAvailable", SqlDbType.Bit);
                    isAvailableParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(isAvailableParam);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    // Check if the username is available
                    args.IsValid = (bool)isAvailableParam.Value;
                }
            }
        }

        protected void regBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(regUser.Text) || string.IsNullOrEmpty(regPass.Text) || string.IsNullOrEmpty(regMail.Text) || string.IsNullOrEmpty(regNum.Text) || Page.IsValid == false)
            {
                // Handle empty fields or invalid form data
                // ...
            }
            else
            {

                // Use the stored procedure for user registration
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("RegisterCustomer", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure; // Set the command type to stored procedure

                        cmd.Parameters.AddWithValue("@UserName", regUser.Text);
                        cmd.Parameters.AddWithValue("@Password", regPass.Text);
                        cmd.Parameters.AddWithValue("@PhoneNumber", regNum.Text);
                        cmd.Parameters.AddWithValue("@CustomerEmail", regMail.Text);

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();

                        Response.Write("<script>alert('User registered')</script>");
                    }
                }
            }
        }


    }
}