﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Nojo
{
    //basically similar to the systems in default
    public partial class ShopFruit : Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {



            if (!IsPostBack)
            {
                // Retrieve products from the database
                List<Product> fruits = GetProductsFromDatabase(1);

                // Bind the products to the Repeater control
                fruitRepeater.DataSource = fruits;
                fruitRepeater.DataBind();
            }
        }

        private List<Product> GetProductsFromDatabase(int categoryId)
        {
            List<Product> products = new List<Product>();
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\NojoDB.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "GetProductsByCategory"; // Use the stored procedure name

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure; // Set the command type to stored procedure

                    // Add the parameter to the command
                    cmd.Parameters.AddWithValue("@CategoryId", categoryId);

                    con.Open();

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Product product = new Product
                        {
                            Name = reader["Name"].ToString(),
                            Price = Convert.ToDouble(reader["Price"]),
                            Cat = reader["CategoryName"].ToString(),
                            imageUrl = reader["PhotoUrl"].ToString(),
                            Qty = 0
                        };

                        products.Add(product);
                    }

                    reader.Close();
                    con.Close();
                }
            }

            return products;
        }


        protected void AddToBasketClick(object sender, EventArgs e)
        {

            if (Session["UserLoggedIn"] == null)
            {
                Response.Redirect("~/Login");
            }
            else
            {
                Button addButton = (Button)sender;
                // Get the corresponding card
                RepeaterItem item = (RepeaterItem)addButton.NamingContainer;
                int itemIndex = item.ItemIndex;

                //Get the qty number that users input to pass forward into the session cart
                TextBox quantNumTextBox = (TextBox)item.FindControl("quantNum");



                int quantity = 0;
                if (int.TryParse(quantNumTextBox.Text, out int parsedQuantity) && parsedQuantity >= 1)
                {
                    quantity = parsedQuantity;




                    // Retrieve the existing cart from the session or make one if none exist
                    List<Product> cart = Session["Cart"] as List<Product>;
                    if (cart == null)
                    {
                        cart = new List<Product>();
                    }

                    Product newProd = new Product();
                    newProd.Name = GetProductsFromDatabase(1)[itemIndex].Name;
                    newProd.Cat = GetProductsFromDatabase(1)[itemIndex].Cat;
                    newProd.Price = GetProductsFromDatabase(1)[itemIndex].Price * quantity;
                    newProd.imageUrl = GetProductsFromDatabase(1)[itemIndex].imageUrl;
                    newProd.Qty = quantity;

                    cart.Add(newProd);


                    Session["Cart"] = cart;
                }
                else
                {
                    quantNumTextBox.Style["border"] = " 3px solid #d42a47";
                }
            }
        }
    }
}