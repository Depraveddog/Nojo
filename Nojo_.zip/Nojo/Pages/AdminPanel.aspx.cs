﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Nojo
{
    public partial class AdminPanel : System.Web.UI.Page
    {
        private readonly string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\NojoDB.mdf;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {
            // Check if the AdminUserName session variable is set and matches the admin table entry
            if (Session["AdminUserName"] != null && Session["AdminPassword"] != null)
            {
                string adminUserName = Session["AdminUserName"].ToString();
                string adminPass = Session["AdminPassword"].ToString();

                // Query the database to check if the admin username exists in the admin table
                bool isAdminUserValid = CheckIfAdminUserIsValid(adminUserName,adminPass);

                if (isAdminUserValid)
                {
                    adminNameDisplay.Text = adminUserName;
                    // Admin user is valid, proceed with loading the admin panel
                    // Your code to load the admin panel here
                }
                else
                {
                    // Admin user is not valid, redirect to login page or show an error message
                    Session.Remove("AdminUserName"); // Clear the session variable
                    Session.Remove("AdminPassword");
                    Response.Redirect("~/Pages/Login.aspx"); // Redirect to the login page or show an error message
                }
            }
            else
            {
                // AdminUserName session variable is not set, redirect to login page or show an error message
                Response.Redirect("~/Pages/Login.aspx"); // Redirect to the login page or show an error message
            }
        }


        private bool CheckIfAdminUserIsValid(string adminUserName, string adminPass)
        {
            bool isAdminUserValid = false;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("CheckAdminCredentials", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Input parameters
                    command.Parameters.AddWithValue("@Username", adminUserName);
                    command.Parameters.AddWithValue("@Password", adminPass); // Use adminPass here

                    // Output parameter
                    SqlParameter isAdminParam = new SqlParameter("@IsAdmin", SqlDbType.Bit);
                    isAdminParam.Direction = ParameterDirection.Output;
                    command.Parameters.Add(isAdminParam);

                    connection.Open();
                    command.ExecuteNonQuery();

                    // Retrieve the result from the output parameter
                    isAdminUserValid = (bool)isAdminParam.Value;
                }
            }

            return isAdminUserValid;
        }

        protected void DetailsView1_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
        {

        }

        protected void LogoutBtn_Click(object sender, EventArgs e)
        {
            Session.Remove("AdminUserName"); // Clear the session variable
            Session.Remove("AdminPassword");
            Response.Redirect("~/Pages/Login.aspx");
        }
    }
}