﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
namespace Nojo
{
    public partial class Cart : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {
                // Set the data source for the Repeater control to the cart in the session
                cartItemRepeater.DataSource = Session["cart"];
                // Bind the data to the Repeater control
                cartItemRepeater.DataBind();
                
            }
        }

        protected void Checkout_Click(object sender, EventArgs e)
        {
            List<Product> cart = Session["Cart"] as List<Product>;
            if (cart.Count > 0)
            {
                string securePath = ConfigurationManager.AppSettings["SecurePath"];
                string checkoutUrl = securePath + "Pages/Checkout.aspx";
                Response.Redirect(checkoutUrl);
               //  Response.Redirect("~/Pages/Checkout");
            }
            else
            {//If there isnt a cart state this message
                cartCheck.Text = "Your cart is empty";
            }


        }

        protected void Remove_Click(object sender, ImageClickEventArgs e)
        {
            ImageButton removeButton = (ImageButton)sender;
            // Get the corresponding card
            RepeaterItem item = (RepeaterItem)removeButton.NamingContainer;
            int itemIndex = item.ItemIndex;

            List<Product> cart = Session["Cart"] as List<Product>;
            //remove the item in cart at the same index as the card
            cart.RemoveAt(itemIndex);
            //store the new cart into the session
            Session["Cart"] = cart;
            //rebind
            cartItemRepeater.DataSource = Session["Cart"];
            cartItemRepeater.DataBind();


        }
    }
}
