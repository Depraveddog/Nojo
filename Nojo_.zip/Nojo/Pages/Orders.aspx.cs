﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Nojo
{
    public partial class Orders : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //creates the list to populate based on the order class from models, this is temporary until we can integrate db so we can store users history
            List<Order> products = new List<Order>
        {
            new Order { Name="Brocolli",Price=3.20, Cat="Vegetables", ImageUrl="/Assets/IMG_2244.png", Qty=1 ,DatePurchased="12/03/2023"},
            new Order { Name="Tomato",Price=2.20, Cat="Fruit", ImageUrl="/Assets/IMG_7202.png", Qty=2  ,DatePurchased="12/03/2023"},
         new Order { Name="Brocolli",Price=3.20, Cat="Vegetables", ImageUrl="/Assets/IMG_2244.png", Qty=1 ,DatePurchased="12/03/2023"},
            new Order { Name="Tomato",Price=2.20, Cat="Fruit", ImageUrl="/Assets/IMG_7202.png", Qty=2  ,DatePurchased="12/03/2023"},new Order { Name="Brocolli",Price=3.20, Cat="Vegetables", ImageUrl="/Assets/IMG_2244.png", Qty=1 ,DatePurchased="12/03/2023"},
            new Order { Name="Tomato",Price=2.20, Cat="Fruit", ImageUrl="/Assets/IMG_7202.png", Qty=2  ,DatePurchased="12/03/2023"},new Order { Name="Brocolli",Price=3.20, Cat="Vegetables", ImageUrl="/Assets/IMG_2244.png", Qty=1 ,DatePurchased="12/03/2023"},
            new Order { Name="Tomato",Price=2.20, Cat="Fruit", ImageUrl="/Assets/IMG_7202.png", Qty=2  ,DatePurchased="12/03/2023"},new Order { Name="Brocolli",Price=3.20, Cat="Vegetables", ImageUrl="/Assets/IMG_2244.png", Qty=1 ,DatePurchased="12/03/2023"},
            new Order { Name="Tomato",Price=2.20, Cat="Fruit", ImageUrl="/Assets/IMG_7202.png", Qty=2  ,DatePurchased="12/03/2023"},

        };

            // Set the data source for the Repeater control
            orderRepeater.DataSource = products;
            // Bind the data to the Repeater control
            orderRepeater.DataBind();

        }
    }
}