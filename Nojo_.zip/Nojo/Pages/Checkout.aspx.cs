﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

namespace Nojo
{
    public partial class Checkout : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Product> cart = Session["Cart"] as List<Product>;

            if(cart != null) { 
            cartNum.Text = cart.Count.ToString();
            
            double cost = 0;

            foreach (var product in cart)
            {
                cost += product.Price;
            }

            costNum.Text ="$" + cost.ToString();
            }

        }

        protected void SubmitBtn_Click(object sender, EventArgs e)
        {
            List<Product> cart = new List<Product>();
            Session["Cart"] = cart;
            Response.Redirect("~/Pages/Default");
            

        }

       
    }
}