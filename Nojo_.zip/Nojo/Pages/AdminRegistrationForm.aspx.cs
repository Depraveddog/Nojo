﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Nojo.Pages
{
    public partial class AdminRegistrationForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void AdminRegBtn_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\NojoDB.mdf;Integrated Security=True";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand("RegisterAdmin", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure; // Set the command type to stored procedure

                    cmd.Parameters.AddWithValue("@UserName", adminUserField.Text);
                    cmd.Parameters.AddWithValue("@Password", createPass.Text);
                    cmd.Parameters.AddWithValue("@MailVerified", 1); // You can set this based on your registration process
                    cmd.Parameters.AddWithValue("@EmployeeEmail", emailField.Text);
                    SqlParameter isRegisteredParam = new SqlParameter("@IsRegistered", SqlDbType.Bit);
                    isRegisteredParam.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(isRegisteredParam);

                    cmd.ExecuteNonQuery();

                    bool isRegistered = (bool)isRegisteredParam.Value;
                    if (isRegistered)
                    {
                        Response.Write("<script>alert('User registered')</script>");
                    }
                    else
                    {
                        Response.Write("<script>alert('You are not an employee')</script>");
                    }
                }

                con.Close();
            }
        }

    }
}