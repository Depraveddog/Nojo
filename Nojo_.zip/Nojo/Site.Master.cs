﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Nojo
{
    public partial class SiteMaster : MasterPage
    {

        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null)
            {
                string user = Session["UserName"].ToString();
                usernameDisplay.Text = user;
            }

            
            if (!IsPostBack)
            {
                bool loggedIn = CheckLoggedIn(); // call the method to check the login status and return a bool value

                if (loggedIn) //based on the loggedIn status, choose the navbar to show
                {
                    navLoggedOut.Visible = false;
                    navLoggedIn.Visible = true;
                }
                else
                {
                    navLoggedOut.Visible = true;
                    navLoggedIn.Visible = false;
                }
            }
        }

        protected bool CheckLoggedIn() // check if it there is a logged in session
        {
            
            if (Session["UserLoggedIn"] != null && (bool)Session["UserLoggedIn"] == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //Redirection links from the button on click
        protected void Login_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Pages/Login");
        }

        protected void LogoutClick(object sender, EventArgs e)
        {

            Session["UserLoggedIn"] = false;
            Response.Redirect("~/Pages/Default");


        }

        protected void OrdersClicked(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/Pages/Orders");
        }

        

        protected void CartClicked(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/Pages/Cart");
        }
    }
}